module.exports={
    url:'mongodb://localhost:27017/jobkro'
    // url:'mongodb+srv://Sandeep:Sandeep@12@cluster0.t587n.mongodb.net/jobkro?retryWrites=true&w=majority'
}